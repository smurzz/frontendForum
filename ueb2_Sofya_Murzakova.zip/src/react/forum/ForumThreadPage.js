import React, { Component } from 'react';
import '../../layout/css/forumPage.css';

import ForumThreadComponent from '../components/ForumThreadComponent';

class ForumThreadPage extends Component {

    render() {
        return (
            < ForumThreadComponent />
        )
    }
}
export default ForumThreadPage;