import React, { Component } from 'react';
import MessageComponent from '../components/MessageComponent';

class MessagePage extends Component {

    render() {
        return (
            < MessageComponent />
        )
    }
}
export default MessagePage;